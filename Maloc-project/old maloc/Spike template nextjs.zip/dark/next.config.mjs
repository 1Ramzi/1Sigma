const nextConfig = {reactStrictMode: false,};

export default nextConfig;